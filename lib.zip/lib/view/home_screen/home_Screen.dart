// view/home_screen.dart

import 'package:aurio/global_constants/color/color_constants.dart';
import 'package:aurio/view/build_plan_screen/build_plan_screen.dart';
import 'package:flutter/material.dart';
import 'package:aurio/view/study_plan_screen/study_plan_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorConstants.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 80),
            Text(
              "Hi, [Name]",
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: ColorConstants.accentColor,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Today's Progress",
              style: TextStyle(fontSize: 16, color: ColorConstants.TextColor),
            ),
            const SizedBox(height: 30),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: ColorConstants.primaryColor.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Week 1: 40% Completed",
                    style: TextStyle(
                      fontSize: 18,
                      color: ColorConstants.TextColor,
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ColorConstants.primaryColor,
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const BuildPlanScreen(),
                        ),
                      );
                    },
                    child: const Text("Start Study Plan"),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
